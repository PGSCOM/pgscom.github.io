# Problemas en la página web. Lo solucionaré lo antes posible. 
# Página web de PGSCOM
Esta es la página web de PGSCOM, ve a [pgscom.github.io](https://pgscom.github.io/)
# Último cambio
05-05-21
# Versión
<<<<<<< HEAD
3.0
=======
2.0
>>>>>>> parent of 48a911a (3.0)
